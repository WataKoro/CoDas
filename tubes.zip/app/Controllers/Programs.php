<?php

namespace App\Controllers;

class Programs extends BaseController
{
    public function index()
    {
        return view('programs');
    }
}
